package main;

import types.Tableau;

public class TableauBlock<T> implements Tableau<T> {

	public TableauBlock(int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean full() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T get(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void set(int i, T v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void push_back(T x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pop_back() {
		// TODO Auto-generated method stub
		
	}

}
